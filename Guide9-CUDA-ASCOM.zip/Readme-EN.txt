﻿Guide 9.1 with CUDA or OpenCL, ASCOM, and N.I.N.A.

INSTALLATION

This package requires the January 1, 2019 build of Guide 9.1 and 64-bit Windows.
Close Guide and the package tools. Back up guide.dat and any files you
will replace, especially asc_link.dll. Extract the ZIP alongside
guide9.exe, then launch Guide9-CUDA.exe or Guide9-OpenCL.exe from that
folder. Run one edition of Guide at a time.

ASTEROID ACCELERATION

Enable “Use MPCORB” in Guide. The GPU speeds up rebuilding the asteroid
index. Guide reuses the index when you move around the chart while the
index is current.

- Guide9-CUDA.exe uses an NVIDIA GPU compatible with sm_86. It requires
  Guide9-CUDA-Calcul.exe and guide9_cuda_index.dll. Tested on an RTX 2050.
- Guide9-OpenCL.exe uses the installed graphics driver. The GPU must
  support OpenCL 1.2 and double precision (FP64). Keep
  Guide9-OpenCL-Calcul.exe and guide9_opencl_index.dll next to the executable.
  Verified on integrated AMD Radeon graphics (gfx90c) and an NVIDIA RTX 2050.

If the driver or GPU is unavailable, or the GPU calculation fails, Guide
rebuilds the index on the CPU. See guide9-cuda.log or guide9-opencl.log
in the Guide folder for the calculation result.

ASCOM

Install the ASCOM Platform and a mount driver that supports 32-bit
clients. In guide.dat, add SCOPE_EPOCH=2000 or update the existing value.
If asc_link.ini specifies CoordinateMode, set it to J2000. In Guide,
open Settings → Scope Control, select ASCOM Scope, confirm, then select
and configure your driver. Guide9-ASCOM.exe is an optional diagnostic tool
for testing the connection and reading mount position. ASCOM was tested
with a simulator.

N.I.N.A. BRIDGE

1. Launch Guide9-NINA.exe and leave its window open or minimized.
2. In N.I.N.A. → Options → Equipment → Planetarium, select Cartes du Ciel,
   host localhost, port 3293. You only need to set this once. The bridge
   uses this entry without running Cartes du Ciel.
3. Center the target in Guide 9. Keep one Guide window open, with Earth
   as the observing planet and J2000 as the coordinate format.
4. In the N.I.N.A. Framing Assistant, click the pin next to Coordinates.
   The chart center appears under the name “Centre Guide 9.”

The bridge imports the live chart center without a .mar file or a mount
move. It recognizes the January 1, 2019 Guide 9.1 build and the included
CUDA and OpenCL builds. The connection stays on your PC. The protocol
was tested in N.I.N.A. 3.3 Nightly #069.

SHA-256 of the original guide9.exe
32893608e82b014c84f9a3487263ec345f3611b75d5b0f786f7a878fbb047c9d
