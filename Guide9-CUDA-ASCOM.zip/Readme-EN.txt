﻿Guide 9.1 – CUDA and ASCOM

This package requires an existing Guide 9.1 installation (January 1, 2019
build). Close Guide and the ASCOM diagnostic tool. Back up guide.dat and
any files in your Guide folder that will be replaced. Copy the six program
and configuration files from this ZIP into that folder, alongside guide9.exe.
Launch Guide9-CUDA.exe.

For ASCOM, install the ASCOM Platform and a telescope driver that supports
32-bit clients. In guide.dat, add SCOPE_EPOCH=2000 or update the existing
value. If your existing asc_link.ini specifies CoordinateMode, set it to J2000.
In Guide9-CUDA, open Settings > Scope Control, select ASCOM Scope, and
confirm. Select your driver and configure its connection. Guide9-ASCOM.exe
is an optional diagnostic tool for testing the connection and reading the
telescope position without issuing a slew command. ASCOM was tested with
a simulator.

To accelerate asteroid indexing, enable Use MPCORB in Guide. The bundled
CUDA engine targets NVIDIA GPUs compatible with sm_86 and was tested on a
GeForce RTX 2050. Guide automatically falls back to the CPU if CUDA is
unavailable.

SHA-256 of the original guide9.exe for checking the required build:
32893608e82b014c84f9a3487263ec345f3611b75d5b0f786f7a878fbb047c9d
